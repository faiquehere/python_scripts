import re

def redact_emails(text_block):
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'

    redacted_text = re.sub(email_pattern, '[EMAIL_REDACTED]', text_block)

    print("--- Original Text ---")
    print(text_block)
    print("\n--- Redacted Text ---")
    print(redacted_text)
    return redacted_text

sample_log = """
User john.doe@example.com reported an issue.
Please forward the details to the admin team at admin@my-company.net.
Contact support-team@help.org for further assistance.
The leak came from test_user@gmail.com, not from an internal account.
"""

redact_emails(sample_log)
